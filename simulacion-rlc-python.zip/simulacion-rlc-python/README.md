# Simulación de circuito RLC en Python

Este repositorio contiene una simulación de un circuito RLC en serie usando `odeint` de SciPy para resolver las ecuaciones diferenciales.

## Cómo correr

```bash
pip install -r requirements.txt
python simulacion_rlc.py
```
