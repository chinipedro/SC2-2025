
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Parámetros del circuito
R = 220    # Ω
L = 0.5    # H
C = 2.2e-6 # F

# Matrices del sistema
A = np.array([[-R/L, -1/L],
              [1/C,    0 ]])
B = np.array([1/L, 0])
C_out = np.array([R, 0])  # Salida: v_R = R * i_L

# Función de entrada (±12V cada 10ms)
def entrada(t):
    periodo = 0.02
    return 12 * np.sign(np.sin(2 * np.pi * t / periodo))

# Ecuaciones diferenciales
def modelo(x, t):
    u = entrada(t)
    dxdt = A @ x + B * u
    return dxdt

# Tiempo de simulación
t = np.arange(0, 0.1, 1e-6)
x0 = [0, 0]

# Resolver
solucion = odeint(modelo, x0, t)

# Resultados
i_L = solucion[:, 0]
v_C = solucion[:, 1]
v_R = C_out @ solucion.T

# Graficar
plt.figure(figsize=(10, 6))
plt.plot(t, v_R, 'b', label='$v_R(t)$ (V)')
plt.plot(t, v_C, 'r', label='$v_C(t)$ (V)')
plt.xlabel('Tiempo (s)')
plt.ylabel('Amplitud')
plt.title('Respuesta del Circuito RLC con Salida en $v_R(t)$')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
